export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type EducationCategory = 'university' | 'technical' | 'certification' | 'complementary'

export type Database = {
  __InternalSupabase: {
    PostgrestVersion: "14.1"
  }
  graphql_public: {
    Tables: { [_ in never]: never }
    Views: { [_ in never]: never }
    Functions: {
      graphql: {
        Args: { extensions?: Json; operationName?: string; query?: string; variables?: Json }
        Returns: Json
      }
    }
    Enums: { [_ in never]: never }
    CompositeTypes: { [_ in never]: never }
  }
  public: {
    Tables: {
      certifications: {
        Row: {
          created_at: string
          credential_url: string | null
          id: string
          is_published: boolean | null
          issue_date: string | null
          issuer: string
          order_index: number | null
          title: Json
          category: EducationCategory | null
        }
        Insert: {
          created_at?: string
          credential_url?: string | null
          id?: string
          is_published?: boolean | null
          issue_date?: string | null
          issuer: string
          order_index?: number | null
          title: Json
          category?: EducationCategory | null
        }
        Update: {
          created_at?: string
          credential_url?: string | null
          id?: string
          is_published?: boolean | null
          issue_date?: string | null
          issuer?: string
          order_index?: number | null
          title?: Json
          category?: EducationCategory | null
        }
        Relationships: []
      }
      contact_messages: {
        Row: {
          created_at: string
          email: string
          id: string
          message: string
          name: string
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          message: string
          name: string
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          message?: string
          name?: string
        }
        Relationships: []
      }
      education: {
        Row: {
          id: string
          title: Json
          institution: Json
          description: Json | null
          category: EducationCategory
          start_date: string | null
          end_date: string | null
          is_current: boolean | null
          credential_url: string | null
          is_published: boolean | null
          order_index: number | null
          created_at: string
        }
        Insert: {
          id?: string
          title: Json
          institution: Json
          description?: Json | null
          category: EducationCategory
          start_date?: string | null
          end_date?: string | null
          is_current?: boolean | null
          credential_url?: string | null
          is_published?: boolean | null
          order_index?: number | null
          created_at?: string
        }
        Update: {
          id?: string
          title?: Json
          institution?: Json
          description?: Json | null
          category?: EducationCategory
          start_date?: string | null
          end_date?: string | null
          is_current?: boolean | null
          credential_url?: string | null
          is_published?: boolean | null
          order_index?: number | null
          created_at?: string
        }
        Relationships: []
      }
      profile: {
        Row: {
          architecture_image_url: string | null
          architecture_text: Json | null
          avatar_url: string | null
          bio: Json | null
          data_analytics_image_url: string | null
          data_analytics_text: Json | null
          display_name: string | null
          github_url: string | null
          linkedin_url: string | null
          twitter_url: string | null
          id: string
          resume_url: Json | null
        }
        Insert: {
          architecture_image_url?: string | null
          architecture_text?: Json | null
          avatar_url?: string | null
          bio?: Json | null
          data_analytics_image_url?: string | null
          data_analytics_text?: Json | null
          display_name?: string | null
          github_url?: string | null
          linkedin_url?: string | null
          twitter_url?: string | null
          id?: string
          resume_url?: Json | null
        }
        Update: {
          architecture_image_url?: string | null
          architecture_text?: Json | null
          avatar_url?: string | null
          bio?: Json | null
          data_analytics_image_url?: string | null
          data_analytics_text?: Json | null
          display_name?: string | null
          github_url?: string | null
          linkedin_url?: string | null
          twitter_url?: string | null
          id?: string
          resume_url?: Json | null
        }
        Relationships: []
      }
      project_technologies: {
        Row: {
          is_primary_stack: boolean | null
          project_id: string
          technology_id: string
        }
        Insert: {
          is_primary_stack?: boolean | null
          project_id: string
          technology_id: string
        }
        Update: {
          is_primary_stack?: boolean | null
          project_id?: string
          technology_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "project_technologies_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "project_technologies_technology_id_fkey"
            columns: ["technology_id"]
            isOneToOne: false
            referencedRelation: "technologies"
            referencedColumns: ["id"]
          },
        ]
      }
      projects: {
        Row: {
          architecture: Json
          cover_image_url: string | null
          created_at: string
          custom_link: string | null
          custom_link_label: string | null
          demo_url: string | null
          id: string
          is_featured: boolean | null
          is_private: boolean | null
          is_published: boolean | null
          metrics: Json | null
          order_index: number | null
          outcome: Json
          problem: Json
          prod_url: string | null
          repo_url: string | null
          slug: string
          summary: Json
          title: Json
        }
        Insert: {
          architecture?: Json
          cover_image_url?: string | null
          created_at?: string
          custom_link?: string | null
          custom_link_label?: string | null
          demo_url?: string | null
          id?: string
          is_featured?: boolean | null
          is_private?: boolean | null
          is_published?: boolean | null
          metrics?: Json | null
          order_index?: number | null
          outcome?: Json
          problem?: Json
          prod_url?: string | null
          repo_url?: string | null
          slug: string
          summary?: Json
          title: Json
        }
        Update: {
          architecture?: Json
          cover_image_url?: string | null
          created_at?: string
          custom_link?: string | null
          custom_link_label?: string | null
          demo_url?: string | null
          id?: string
          is_featured?: boolean | null
          is_private?: boolean | null
          is_published?: boolean | null
          metrics?: Json | null
          order_index?: number | null
          outcome?: Json
          problem?: Json
          prod_url?: string | null
          repo_url?: string | null
          slug?: string
          summary?: Json
          title?: Json
        }
        Relationships: []
      }
      technologies: {
        Row: {
          category: string
          color: string | null
          icon_slug: string | null
          logo_url: string | null
          id: string
          name: string
        }
        Insert: {
          category: string
          color?: string | null
          icon_slug?: string | null
          logo_url?: string | null
          id?: string
          name: string
        }
        Update: {
          category?: string
          color?: string | null
          icon_slug?: string | null
          logo_url?: string | null
          id?: string
          name?: string
        }
        Relationships: []
      }
    }
    Views: { [_ in never]: never }
    Functions: { [_ in never]: never }
    Enums: { [_ in never]: never }
    CompositeTypes: { [_ in never]: never }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">
type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
  | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
  | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
  ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
    DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
  : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
    DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
  ? R
  : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
    DefaultSchema["Views"])
  ? (DefaultSchema["Tables"] &
    DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
      Row: infer R
    }
  ? R
  : never
  : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
  | keyof DefaultSchema["Tables"]
  | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
  ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
  : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
    Insert: infer I
  }
  ? I
  : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
  ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
    Insert: infer I
  }
  ? I
  : never
  : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
  | keyof DefaultSchema["Tables"]
  | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
  ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
  : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
    Update: infer U
  }
  ? U
  : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
  ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
    Update: infer U
  }
  ? U
  : never
  : never

export const Constants = {
  graphql_public: { Enums: {} },
  public: { Enums: {} },
} as const
